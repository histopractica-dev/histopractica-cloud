module.exports = require("../lib/adapter")(require("../lib/functions/progress").handler);
