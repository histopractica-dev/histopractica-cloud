module.exports = require("../lib/adapter")(require("../lib/functions/retry-notifications").handler);
