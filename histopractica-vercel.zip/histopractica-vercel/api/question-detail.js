module.exports = require("../lib/adapter")(require("../lib/functions/question-detail").handler);
