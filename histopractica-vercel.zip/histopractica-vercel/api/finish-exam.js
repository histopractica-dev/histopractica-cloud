module.exports = require("../lib/adapter")(require("../lib/functions/finish-exam").handler);
