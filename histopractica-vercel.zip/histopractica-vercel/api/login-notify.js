module.exports = require("../lib/adapter")(require("../lib/functions/login-notify").handler);
