module.exports = require("../lib/adapter")(require("../lib/functions/public-config").handler);
