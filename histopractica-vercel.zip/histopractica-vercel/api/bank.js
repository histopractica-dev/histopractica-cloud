module.exports = require("../lib/adapter")(require("../lib/functions/bank").handler);
